﻿using EFCodeFirstDemo.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCodeFirstDemo.DBContext
{
    public class UserDbContext : DbContext
    {
        public UserDbContext() : base("name = UserEntities")
        {

        }

        //Add your Model or Entity
        public virtual DbSet<User> Users { get; set; }
    }
}
