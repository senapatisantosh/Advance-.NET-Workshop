﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCodeFirstDemo.Models
{
    //User Entity
    public class User
    {
        public long UserId { get; set; }
        public string UserName { get; set; }
        public string EmailID { get; set; }
    }
}
