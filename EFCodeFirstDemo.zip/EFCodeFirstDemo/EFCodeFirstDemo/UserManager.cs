﻿using EFCodeFirstDemo.DBContext;
using EFCodeFirstDemo.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCodeFirstDemo
{
    class UserManager
    {
        public static UserDbContext userDbContext = new UserDbContext();
        public static void CreatUserUsingEF()
        {
            User user = new User();
            user.UserName = "Santosh";
            user.EmailID = "a.dasdas@gmail.com";

            //Logic For Adding the user to the DB Using EF
            userDbContext.Users.Add(user);
            userDbContext.SaveChanges();
            Console.WriteLine("User Added Successfully");
        }
        public static void ReadUserUsingEF()
        {
            List<User> users = userDbContext.Users.ToList<User>();
            foreach (var item in users)
            {
                Console.WriteLine($"id:{item.UserId}, " +
                                  $"UserName:{item.UserName}," +
                                  $" EmailId:{item.EmailID}");
            }

        }
        public static void UpdateUserUsingEF()
        {
            //Retriving The Existing Row
            User user = userDbContext.Users.Find(1);

            //Update the Column
            user.UserName = "SANTOSH KUMAR SENAPATI";

            //Change the State
            userDbContext.Entry(user).State = EntityState.Modified;

            //Update the Database 
            userDbContext.SaveChanges();

            Console.WriteLine("User Updates Successfully");
        }
        public static void DeleteUserUsingEF()
        {
            //Retriving The Existing Row
            User user = userDbContext.Users.Find(1);

            //Remove the Row in the table
            userDbContext.Users.Remove(user);

            //Update the Database
            userDbContext.SaveChanges();
        }
    }
}
