﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCodeFirstDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // CRUD Using EF
            //UserManager.CreatUserUsingEF();
            UserManager.ReadUserUsingEF();
            //UserManager.UpdateUserUsingEF();
            //UserManager.DeleteUserUsingEF();

            Console.ReadKey();
        }
    }
}
